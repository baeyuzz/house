module.exports = {
    publicPath: '/happyhouse'
  }