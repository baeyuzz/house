export default{
    GET_QNALIST : 'getQnaList',
    GET_QNA : 'getQna',
    ADD_QNA : 'addQna',
    MODIFY_QNA : 'modifyQnA',
    // REMOVE_QNA : 'deleteNotice',
    // REPLY_QNA : 'replyQnA',
}